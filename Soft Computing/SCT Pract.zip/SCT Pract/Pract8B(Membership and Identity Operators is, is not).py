# Python program to illustrate the use
# of 'is' identity operator
'''x = 5
if (type(x) is int):
 print ("true")
else:
 print ("false")'''
# Python program to illustrate the
# use of 'is not' identity operator
x = 1
if (type(x) is not int):
 print ("true")
else:
 print ("false") 
